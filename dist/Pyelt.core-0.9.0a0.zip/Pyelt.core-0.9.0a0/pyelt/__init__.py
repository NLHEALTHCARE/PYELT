""" NL Healthcare DWH2.0 / pyelt

.. moduleauthor:: Henk-Jan van Reenen <henk-jan.van.reenen@nlhealthcareclinics.com>,
                  Rob Wiegerinck <rob.wiegerinck@nlhealthcareclinics.com>,
                  Daniel Kapitan <daniel.kapitan@nlhealthcareclinics.com>

"""

__docformat__ = 'restructuredtext'