current_version = ('0.9.1.a0','hjvreenen','package-build V0.9.1.a0', '2ee6924fbf6fa9c3f0c81c4e192e3db2d3599ef4', '2016-09-15 11:08:42.594143')
version_archive = [
    ('0.9.1.a0','hjvreenen','package-build V0.9.1.a0', '2ee6924fbf6fa9c3f0c81c4e192e3db2d3599ef4', '2016-09-15 11:08:42.594143')
, ]
